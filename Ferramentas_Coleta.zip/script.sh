#! /bin/bash

rm *.log
rm *.csv
python getData2.0.py 1 >> DATA_MN91.log
python getData2.0.py 2 >> DATA_MN92.log
python getData2.0.py 3 >> DATA_MN93.log
python media.py >> MEDIA.log
python export.py