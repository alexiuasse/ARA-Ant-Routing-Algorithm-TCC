# -*- coding: iso-8859-1 -*-

import sys, re, os

def data(name_file,words_to_seek):
    print "oi"
    for name_file in name_file:
        with open("./results/"+name_file,"r") as work_file:
            print '\nNome do arquivo: ' + name_file + '\n'
            for word in words_to_seek:
                for line in work_file:
                    if any(word in line for word in words_to_seek):
                        x = re.findall(r'\S+', line)
                        print x[1] + "\t" + x[2] + "\t" + x[3]
         
if __name__ == "__main__":
    instance = sys.argv[1]
    words_to_seek = open("toSeek.txt").read().splitlines()
    N91_file = []
    N92_file = []
    N93_file = []
    
    for name_file in os.listdir("./results"):
        if name_file.endswith(".sca"):
            if "N91" in name_file:
                N91_file.append(name_file)
            if "N92" in name_file:
                N92_file.append(name_file)
            if "N93" in name_file:
                N93_file.append(name_file)
                
    if instance == str(1):
        data(N91_file,words_to_seek)
    if instance == str(2):
        data(N92_file,words_to_seek)
    if instance == str(3):
        data(N93_file,words_to_seek)