# -*- coding: iso-8859-1 -*-

import sys, re, os

def data(name_file,words_to_seek,host,ich):
    sumer = 0
    count = 14
    #c = 0
    #b = 0
    for name_file in name_file:
        with open(name_file,"r") as work_file:
            for word in words_to_seek:
                for line in work_file:
                    line_parsed = re.findall(r'\S+', line)
                    if len(line_parsed) > 2 and line_parsed[1] == words_to_seek[ich]:
                        #c = c + 1
                        if "host["+str(host)+"]" in line:
                            #b = b + 1
                            x = re.findall(r'\S+', line)
                            sumer = sumer + int(x[2])
    return sumer/count
    #print "host[" + str(host)+"]" + "\t" + words_to_seek[ich] + "\t" + str(sumer/count)# + '\t' + str(sumer) + '/' +str(count)# + "\t" + str(c) + "\t" + str(b)
         
if __name__ == "__main__":
    #instance = sys.argv[1]
    words_to_seek = open("toSeek.txt").read().splitlines()
    N91_file = []
    N92_file = []
    N93_file = []
    nodes = 9
    words = 13
    
    for name_file in os.listdir("./"):
        if name_file.endswith(".log"):
            if "N91" in name_file:
                N91_file.append(name_file)
            if "N92" in name_file:
                N92_file.append(name_file)
            if "N93" in name_file:
                N93_file.append(name_file)
                
    for i in range(1,4):
        instance = i
        
        print str(instance) + " DIA"
        
        print 'host[*]\t',
        for i in words_to_seek:
            print str(i)+'\t',
    
        #if instance == 1:
        for i in range(nodes):
            average = []
            for j in range(words):
                if instance == 1:
                    average.append(data(N91_file,words_to_seek,i,j))
                elif instance == 2:
                    average.append(data(N92_file,words_to_seek,i,j))
                elif instance == 3:
                    average.append(data(N93_file,words_to_seek,i,j))
            print "\nhost["+str(i)+"]\t",
            for i in average:
                print str(i)+'\t',
        print "\n"